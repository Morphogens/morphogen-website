// var createControls = require('./controls');
const normalize = require('gl-vec3/normalize')
const glsl = require('glslify')
const baboon = require('baboon-image')

console.log(baboon)

require('regl')({
    pixelRatio: 0.5,
    extensions: [
        'oes_texture_float',
    ],
    optionalExtensions: [
        'oes_texture_half_float'
    ],
    attributes: {
        antialias: false
    },
    onDone: require('fail-nicely')(main)
});

function main(regl) {
    let w;
    let h;
    let scale = 1.0;

    let states = []

    let state = {
        relDiffusion: 2.0,
        f: 0.037,
        hue: 0,
        k: 0.06,
    };

    let container = document.getElementById('container')
    let test = document.getElementById('test')

    container.addEventListener('scroll', (event) => {
        // console.log(container.scrollTop)
        console.log(test.getBoundingClientRect().left, test.offsetWidth)
        console.log(test.getBoundingClientRect().top, test.offsetHeight)
    })

    let controlRoot = document.createElement('div');
    // document.body.appendChild(createControls(null, controlRoot));

    // require('control-panel')([
    //   {label: 'relDiffusion', type: 'range', min: 1.0, max: 4.0, initial: state.relDiffusion, step: 0.1},
    //   {label: 'f', type: 'range', min: 0, max: 0.1, initial: state.f, step: 0.001},
    //   {label: 'k', type: 'range', min: 0, max: 0.1, initial: state.k, step: 0.001},
    //   {label: 'hue', type: 'range', min: 0, max: 360, initial: state.hue, step: 1},
    //   {label: 'restart', type: 'button', action: restart},
    //   {label: 'auto-restart', type: 'checkbox', initial: false},
    // ], {
    //   root: controlRoot,
    //   width: Math.min(300, window.innerWidth),
    // }).on('input', data => {
    //   var changed = data.k !== state.k || data.f !== state.f || data.relDiffusion !== state.relDiffusion;
    //   Object.assign(state, data);
    //   if (changed && data['auto-restart']) restart();
    // });


    let xy = new Float32Array(2);
    let xyBuf = regl.buffer(xy);


    let rect = new Float32Array(4);
    let rectBuf = regl.buffer(rect);

    function restart() {
        w = Math.floor(regl._gl.canvas.width * scale);
        h = Math.floor(regl._gl.canvas.height * scale);
        states = [0, 1].map(i => (states[i] || regl.framebuffer)({
            colorType: regl.hasExtension('oes_texture_half_float') ? 'half float' : 'float',
            width: w,
            height: h,
        }));

        initialize({dst: states[0]});

        xy[0] = 0.0;
        xy[1] = 0.0;
        xyBuf = xyBuf(xy);
        dropAPoint({dst: states[0]});
    }

    require('mouse-change')(regl._gl.canvas, (buttons, x, y, mods) => {
        if (buttons) {
            xy[0] = x / regl._gl.canvas.clientWidth * 2.0 - 1.0;
            xy[1] = (1.0 - y / regl._gl.canvas.clientHeight) * 2.0 - 1.0;
            xyBuf = xyBuf(xy);
            dropAPoint({dst: states[0]});
        }
    });

    regl._gl.canvas.addEventListener('touchmove', function (event) {
        event.preventDefault();
        for (var i = 0; i < event.touches.length; i++) {
            var t = event.touches[i];
            xy[0] = t.clientX / regl._gl.canvas.clientWidth * 2.0 - 1.0;
            xy[1] = (1.0 - t.clientY / regl._gl.canvas.clientHeight) * 2.0 - 1.0;
            xyBuf = xyBuf(xy);
            dropAPoint({dst: states[0]});
        }
    });

    var dropAPoint = regl({
        vert: `
            precision mediump float;
            varying vec2 uv;
            attribute vec2 xy;
            void main () {
                uv = xy * 0.5 + 0.5;
                gl_Position = vec4(xy, 0, 1);
                gl_PointSize = 20.1;
            }
        `,
        frag: `
            precision mediump float;
            varying vec2 uv;
            void main () {
                if (dot(gl_PointCoord.xy - 0.5, gl_PointCoord.xy - 0.5) > 0.25) discard;
                gl_FragColor = vec4(vec3(0.5), 1.0);
            }
        `,
        attributes: {xy: xyBuf},
        framebuffer: regl.prop('dst'),
        depth: {enable: false},
        primitive: 'point',
        count: 1
    });

    var clear_rect = regl({
        vert: `
            precision mediump float;
            varying vec2 uv;
            attribute vec2 xy;
            void main () {
                uv = xy * 0.5;
                gl_Position = vec4(xy, 0, 1);
                gl_PointSize = 20.1;
            }
        `,
        frag: `
            precision mediump float;
            varying vec2 uv;
            void main () {
                if (dot(gl_PointCoord.xy - 0.5, gl_PointCoord.xy - 0.5) > 0.25) discard;
                gl_FragColor = vec4(vec3(0.5), 1.0);
            }
        `,
        attributes: {xy: xyBuf},
        framebuffer: regl.prop('dst'),
        depth: {enable: false},
        primitive: 'point',
        count: 1
    });

    var initialize = regl({
        vert: `
            precision mediump float;
            attribute vec2 xy;
            varying vec2 uv;
            void main () {
                uv = xy * 0.5 + 0.5;
                uv.y = 1.0-uv.y;
                gl_Position = vec4(xy, 0, 1);
            }
        `,
        // frag: `
        //     precision mediump float;
        //     varying vec2 uv;
        //     void main () {
        //         gl_FragColor = vec4(1, 0, 0, 0);
        //     }
        // `,
        frag: `
            precision mediump float;
            uniform sampler2D texture;
            varying vec2 uv;
            void main () {
                vec4 val = texture2D(texture, uv);
                // vec4 val = texture2D(texture, vec2(uv.x, 1.0-uv.y));
                if (val.r > 0.5) {
                    gl_FragColor = vec4(0, 1, 0, 0);
                } else {
                    gl_FragColor = vec4(1, 0, 0, 0);
                }

            }
        `,
        attributes: {xy: [-4, -4, 0, 4, 4, -4]},
        uniforms: {
            texture: regl.texture(baboon),
        },
        framebuffer: regl.prop('dst'),
        depth: {enable: false},
        count: 3,

    });


    var compute = regl({
        vert: `
            precision mediump float;
            attribute vec2 xy;
            varying vec2 vUv;
            void main () {
                vUv = xy * 0.5 + 0.5;
                gl_Position = vec4(xy, 0, 1);
            }
        `,
        frag: glsl`
            precision mediump float;
            uniform sampler2D u_src;
            uniform vec2 u_size;
            uniform float scale;
            varying vec2 vUv;
            const float F = 0.04, K = 0.06;
            float D_a = 0.2*scale, D_b = 0.1*scale;

            void main() {
                // vec2 p = gl_FragCoord.xy,
                vec2 p = vUv,
                     n = p + vec2(0.0, 1.0)*u_size,
                     e = p + vec2(1.0, 0.0)*u_size,
                     s = p + vec2(0.0, -1.0)*u_size,
                     w = p + vec2(-1.0, 0.0)*u_size;

                vec4 val = texture2D(u_src, p);

                vec4 lap = texture2D(u_src, n)
                    + texture2D(u_src, e)
                    + texture2D(u_src, s)
                    + texture2D(u_src, w)
                    - 4.0 * val;

                val += vec4(D_a * lap.x - val.x*val.y*val.y + F * (1.0-val.x),
                            D_b * lap.y + val.x*val.y*val.y - (K+F) * val.y,
                            D_a * lap.z - val.z*val.w*val.w + F * (1.0-val.z),
                            D_b * lap.w + val.z*val.w*val.w - (K+F) * val.w);

                /*  Make the two systems mutually exclusive by having the
                    dominant suppress the other. */
                if (val.y > val.w) {
                    gl_FragColor = vec4(val.x, val.y, val.z, val.w/2.0);
                } else {
                    gl_FragColor = vec4(val.x, val.y/2.0, val.z, val.w);
                }
            }
        `,
        attributes: {xy: [-4, -4, 0, 4, 4, -4]},
        uniforms: {
            uRule: [
                state.relDiffusion,
                state.f,
                state.k
            ],
            scale: 0.3,
            u_src: regl.prop('src'),
            u_size: ctx => [1 / ctx.framebufferWidth, 1 / ctx.framebufferHeight],
        },
        framebuffer: regl.prop('dst'),
        depth: { enable: false },
        count: 3
    });

    var drawToScreen = regl({
        vert: `
            precision mediump float;
            attribute vec2 xy;
            varying vec2 uv;
            void main () {
                uv = xy * 0.5 + 0.5;
                gl_Position = vec4(xy, 0, 1);
            }
        `,
        frag: `
            precision mediump float;
            varying vec2 uv;
            uniform sampler2D src;
            uniform vec3 color1, color2, color3;
            void main () {
                vec2 value = texture2D(src, uv).xy;
                gl_FragColor = vec4(
                    (
                        1.0 * (1.0 - value.x) * color1 +
                        1.0 * (0.5 + 0.5 * value.y) * color2
                    ),
                    1.0
                );
            }
        `,
        uniforms: {
            color1: () => [0, 1, 2].map(i => 0.5 + 0.5 * Math.cos((i - 0.5) / 3 * Math.PI * 2 + state.hue * Math.PI / 180)),
            color2: () => [0, 1, 2].map(i => 0.5 + 0.5 * Math.cos((i + 1.3) / 3 * Math.PI * 2 + state.hue * Math.PI / 180)),
            src: regl.prop('src'),
        },
        attributes: {xy: [-4, -4, 0, 4, 4, -4]},
        depth: {enable: false},
        count: 3
    });


    restart();

    window.addEventListener('resize', restart);

    var itersPerFrame = 10;
    var prevTime = null;
    var slowCount = 0;
    regl.frame(({tick, time}) => {
        if (prevTime) {
            var dt = time - prevTime;
            if (dt > 1.4 / 60) {
                slowCount++;
            } else if (dt < 1.1 / 60) {
                slowCount--;
            }
            if (slowCount > 10) {
                slowCount = 0;
                itersPerFrame = Math.max(1, itersPerFrame - 1);
            }
            if (slowCount < -10) {
                slowCount = 0;
                itersPerFrame = Math.min(10, itersPerFrame + 1);
            }
        }
        prevTime = time;

        for (var i = 0; i < itersPerFrame; i++) {
            compute({src: states[0], dst: states[1]});
            compute({src: states[1], dst: states[0]});
        }
        drawToScreen({src: states[0]});
    });
}